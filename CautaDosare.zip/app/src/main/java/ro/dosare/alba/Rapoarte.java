package ro.dosare.alba;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import ro.dosare.alba.Portal.Dosar;
import ro.dosare.alba.Portal.Termen;

/** Formatare text si generarea fisierelor Word (.docx) si Excel (.xlsx). Fara Android. */
public final class Rapoarte {
    private Rapoarte() {
    }

    // ------------------------------------------------------------------ texte

    /** 2026-10-15 -> 15.10.2026 */
    public static String dataRo(String iso) {
        if (iso != null && iso.length() == 10 && iso.charAt(4) == '-') {
            return iso.substring(8, 10) + "." + iso.substring(5, 7) + "." + iso.substring(0, 4);
        }
        return iso == null ? "" : iso;
    }

    public static String cand(Termen t) {
        StringBuilder b = new StringBuilder(dataRo(t.data));
        if (!t.ora.isEmpty()) b.append(", ora ").append(t.ora);
        if (!t.complet.isEmpty()) b.append(", complet ").append(t.complet);
        return b.toString();
    }

    /** "HotarareDefinitiva" -> "Hotarare definitiva" */
    public static String tipDocument(Termen t) {
        String s = t.document.replace('_', ' ').replaceAll("(?<=[a-z])(?=[A-Z])", " ").trim();
        if (s.isEmpty()) return "";
        s = s.toLowerCase();
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    /** {solutia pe o linie, rezumatul} pentru un termen trecut. */
    public static String[] solutie(Termen t) {
        if (!t.areSolutie()) return new String[]{"fără soluție publicată", ""};
        String tip = tipDocument(t);
        String nr = t.nrDoc.isEmpty() ? "" : " nr. " + t.nrDoc;
        String pron = (!t.dataPronuntare.isEmpty() && !t.dataPronuntare.equals(t.data))
                ? " (pronunțată " + dataRo(t.dataPronuntare) + ")" : "";
        String cap = tip.isEmpty() ? "" : tip + nr + pron + ": ";
        return new String[]{(cap + t.solutie).trim(), t.sumar.trim().replaceAll("\\s+", " ")};
    }

    /** Toate termenele viitoare, din toate dosarele, cel mai apropiat primul. */
    public static List<Object[]> termeneViitoare(List<Dosar> dosare) {
        List<Object[]> rez = new ArrayList<>();
        for (Dosar d : dosare) for (Termen t : d.viitoare) rez.add(new Object[]{t, d});
        Collections.sort(rez, (a, b) -> ((Termen) a[0]).cheie().compareTo(((Termen) b[0]).cheie()));
        return rez;
    }

    /** Hotararile cu numar, de cautat pe ReJust dupa numarul dosarului. */
    public static List<String> hotarariDeCautat(List<Dosar> dosare) {
        List<String> rez = new ArrayList<>();
        for (Dosar d : dosare) {
            for (Termen t : d.trecute) {
                if (t.nrDoc.isEmpty()) continue;
                String tip = tipDocument(t).isEmpty() ? "Hotărâre" : tipDocument(t);
                String data = dataRo(t.dataPronuntare.isEmpty() ? t.data : t.dataPronuntare);
                rez.add("Dosar " + d.numar + " (" + d.instanta + ") – " + tip + " nr. " + t.nrDoc + " din " + data);
            }
        }
        return rez;
    }

    public static String numeFisier(String nume, String azi) {
        String n = nume.replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_+|_+$", "");
        if (n.isEmpty()) n = "cautare";
        return "dosare_" + n + "_" + azi;
    }

    // ------------------------------------------------------------------ Word

    private static String p(String text, int marime, boolean bold, String culoare,
                            int spatiuDupa, String fundal, int indent) {
        StringBuilder rpr = new StringBuilder();
        if (bold) rpr.append("<w:b/>");
        rpr.append("<w:sz w:val=\"").append(marime * 2).append("\"/><w:szCs w:val=\"").append(marime * 2).append("\"/>");
        if (culoare != null) rpr.append("<w:color w:val=\"").append(culoare).append("\"/>");
        StringBuilder ppr = new StringBuilder("<w:spacing w:after=\"" + spatiuDupa + "\"/>");
        if (indent > 0) ppr.append("<w:ind w:left=\"").append(indent).append("\"/>");
        if (fundal != null) ppr.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(fundal).append("\"/>");
        StringBuilder runs = new StringBuilder();
        String[] linii = (text == null ? "" : text).split("\n", -1);
        for (int i = 0; i < linii.length; i++) {
            if (i > 0) runs.append("<w:br/>");
            runs.append("<w:t xml:space=\"preserve\">").append(Xml.esc(linii[i])).append("</w:t>");
        }
        return "<w:p><w:pPr>" + ppr + "</w:pPr><w:r><w:rPr>" + rpr + "</w:rPr>" + runs + "</w:r></w:p>";
    }

    private static String p(String text) {
        return p(text, 14, false, null, 80, null, 0);
    }

    public static byte[] word(String nume, List<Dosar> dosare, String azi) throws IOException {
        StringBuilder c = new StringBuilder();
        c.append(p("Dosare pentru: " + nume, 22, true, "1F4E79", 120, null, 0));
        c.append(p("Instanțele din Alba Iulia – generat la " + dataRo(azi) + " – " + dosare.size() + " dosare",
                13, false, "595959", 240, null, 0));

        c.append(p("Termene viitoare", 18, true, "1F4E79", 80, null, 0));
        List<Object[]> viitoare = termeneViitoare(dosare);
        if (viitoare.isEmpty()) {
            c.append(p("Nu există termene viitoare în aceste dosare."));
        } else {
            for (Object[] o : viitoare) {
                Termen t = (Termen) o[0];
                Dosar d = (Dosar) o[1];
                c.append(p(cand(t) + "\nDosar " + d.numar + " – " + d.instanta + "\n" + d.obiect,
                        14, true, null, 100, "FFF2CC", 0));
            }
        }
        c.append(p("", 8, false, null, 200, null, 0));

        for (Dosar d : dosare) {
            c.append(p("Dosar " + d.numar, 18, true, "1F4E79", 60, null, 0));
            c.append(p(d.instanta + "  |  înregistrat " + dataRo(d.dataInregistrare), 14, true, null, 80, null, 0));
            c.append(p("Materie: " + d.materie + "   Stadiu: " + d.stadiu));
            c.append(p("Obiect: " + d.obiect));
            c.append(p("Părți: " + d.parti));
            if (!d.viitoare.isEmpty()) {
                c.append(p("Termene viitoare:", 14, true, "9C5700", 80, null, 0));
                for (Termen t : d.viitoare) c.append(p("• " + cand(t), 14, true, null, 60, "FFF2CC", 280));
            }
            if (!d.trecute.isEmpty()) {
                c.append(p("Termene trecute:", 14, true, null, 80, null, 0));
                for (int i = d.trecute.size() - 1; i >= 0; i--) {
                    Termen t = d.trecute.get(i);
                    String[] s = solutie(t);
                    String txt = "• " + cand(t) + "\n   " + s[0] + (s[1].isEmpty() ? "" : "\n   " + s[1]);
                    c.append(p(txt, 14, false, null, 80, null, 280));
                }
            }
            if (d.viitoare.isEmpty() && d.trecute.isEmpty()) c.append(p("Nu sunt termene afișate pe portal."));
            c.append(p("", 8, false, null, 200, null, 0));
        }

        List<String> hot = hotarariDeCautat(dosare);
        if (!hot.isEmpty()) {
            c.append(p("Textul complet al hotărârilor", 18, true, "1F4E79", 80, null, 0));
            c.append(p("Textul integral nu este pe portal.just.ro. Îl găsești gratuit pe www.rejust.ro "
                            + "(portalul Consiliului Superior al Magistraturii, necesită cont gratuit): caută după "
                            + "numărul dosarului de mai jos. Hotărârile de acolo sunt anonimizate și apar uneori "
                            + "după câteva săptămâni sau luni.",
                    13, false, "595959", 160, null, 0));
            for (String h : hot) c.append(p("• " + h, 14, false, null, 80, null, 280));
        }

        String document = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">"
                + "<w:body>" + c
                + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>"
                + "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" "
                + "w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>";

        Map<String, String> parti = new LinkedHashMap<>();
        parti.put("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                + "</Types>");
        parti.put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
                + "</Relationships>");
        parti.put("word/document.xml", document);
        return zip(parti);
    }

    // ------------------------------------------------------------------ Excel

    private static final class Siruri {
        final List<String> lista = new ArrayList<>();
        final Map<String, Integer> index = new LinkedHashMap<>();

        int id(String s) {
            String t = s == null ? "" : s;
            Integer i = index.get(t);
            if (i == null) {
                i = lista.size();
                index.put(t, i);
                lista.add(t);
            }
            return i;
        }

        String xml() {
            StringBuilder b = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\""
                    + lista.size() + "\" uniqueCount=\"" + lista.size() + "\">");
            for (String s : lista) b.append("<si><t xml:space=\"preserve\">").append(Xml.esc(s)).append("</t></si>");
            return b.append("</sst>").toString();
        }
    }

    private static String col(int n) {
        StringBuilder s = new StringBuilder();
        n += 1;
        while (n > 0) {
            int r = (n - 1) % 26;
            s.insert(0, (char) ('A' + r));
            n = (n - 1) / 26;
        }
        return s.toString();
    }

    private static double inaltime(String[] valori, int[] latimi) {
        int max = 1;
        for (int i = 0; i < valori.length; i++) {
            int car = Math.max((int) (latimi[i] * 0.85), 5);
            int linii = 0;
            for (String l : (valori[i] == null ? "" : valori[i]).split("\n", -1)) {
                linii += Math.max(1, (l.length() + car - 1) / car);
            }
            max = Math.max(max, linii);
        }
        return Math.min(409, max * 19 + 4);
    }

    /** O foaie: titluri, latimi, randuri (valori) si care randuri sunt evidentiate. */
    private static final class Foaie {
        String nume;
        String[] titluri;
        int[] latimi;
        final List<String[]> randuri = new ArrayList<>();
        final List<Boolean> evidentiat = new ArrayList<>();
    }

    private static String foaieXml(Siruri sir, Foaie f) {
        StringBuilder rows = new StringBuilder();
        rows.append("<row r=\"1\" ht=\"").append(inaltime(f.titluri, f.latimi)).append("\" customHeight=\"1\">");
        for (int i = 0; i < f.titluri.length; i++) {
            rows.append("<c r=\"").append(col(i)).append("1\" s=\"1\" t=\"s\"><v>").append(sir.id(f.titluri[i])).append("</v></c>");
        }
        rows.append("</row>");
        for (int r = 0; r < f.randuri.size(); r++) {
            String[] v = f.randuri.get(r);
            int nr = r + 2;
            String stil = f.evidentiat.get(r) ? "3" : "2";
            rows.append("<row r=\"").append(nr).append("\" ht=\"").append(inaltime(v, f.latimi)).append("\" customHeight=\"1\">");
            for (int i = 0; i < v.length; i++) {
                rows.append("<c r=\"").append(col(i)).append(nr).append("\" s=\"").append(stil)
                        .append("\" t=\"s\"><v>").append(sir.id(v[i])).append("</v></c>");
            }
            rows.append("</row>");
        }
        StringBuilder cols = new StringBuilder();
        for (int i = 0; i < f.latimi.length; i++) {
            cols.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1)
                    .append("\" width=\"").append(f.latimi[i]).append("\" customWidth=\"1\"/>");
        }
        String ultima = col(f.titluri.length - 1) + (f.randuri.size() + 1);
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<dimension ref=\"A1:" + ultima + "\"/>"
                + "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" "
                + "activePane=\"bottomLeft\" state=\"frozen\"/>"
                + "<selection pane=\"bottomLeft\" activeCell=\"A2\" sqref=\"A2\"/></sheetView></sheetViews>"
                + "<sheetFormatPr defaultRowHeight=\"19\"/>"
                + "<cols>" + cols + "</cols><sheetData>" + rows + "</sheetData>"
                + "<autoFilter ref=\"A1:" + ultima + "\"/>"
                + "<pageMargins left=\"0.5\" right=\"0.5\" top=\"0.75\" bottom=\"0.75\" header=\"0.3\" footer=\"0.3\"/>"
                + "</worksheet>";
    }

    public static byte[] excel(List<Dosar> dosare, String azi) throws IOException {
        Foaie fd = new Foaie();
        fd.nume = "Dosare";
        fd.titluri = new String[]{"Instanța", "Nr. dosar", "Data înreg.", "Materie", "Stadiu", "Obiect", "Părți",
                "Termene viitoare", "Termene trecute și soluții"};
        fd.latimi = new int[]{24, 18, 14, 16, 12, 35, 45, 30, 80};

        Foaie ft = new Foaie();
        ft.nume = "Termene";
        ft.titluri = new String[]{"Data", "Ora", "Stare", "Nr. dosar", "Instanța", "Complet", "Soluție",
                "Rezumat soluție", "Obiect"};
        ft.latimi = new int[]{14, 9, 11, 18, 24, 12, 40, 60, 35};

        List<Object[]> viit = new ArrayList<>();   // {cheie, rand}
        List<Object[]> trec = new ArrayList<>();
        for (Dosar d : dosare) {
            StringBuilder v = new StringBuilder();
            for (Termen t : d.viitoare) {
                if (v.length() > 0) v.append("\n");
                v.append(cand(t));
            }
            StringBuilder tr = new StringBuilder();
            for (int i = d.trecute.size() - 1; i >= 0; i--) {
                Termen t = d.trecute.get(i);
                String[] s = solutie(t);
                if (tr.length() > 0) tr.append("\n");
                tr.append(cand(t)).append(": ").append(s[0]);
                if (!s[1].isEmpty()) tr.append(" – ").append(s[1]);
            }
            fd.randuri.add(new String[]{d.instanta, d.numar, dataRo(d.dataInregistrare), d.materie, d.stadiu,
                    d.obiect, d.parti, v.toString(), tr.toString()});
            fd.evidentiat.add(!d.viitoare.isEmpty());

            for (Termen t : d.viitoare) {
                viit.add(new Object[]{t.cheie(), new String[]{dataRo(t.data), t.ora, "VIITOR", d.numar, d.instanta,
                        t.complet, "", "", d.obiect}});
            }
            for (Termen t : d.trecute) {
                String[] s = solutie(t);
                trec.add(new Object[]{t.cheie(), new String[]{dataRo(t.data), t.ora, "trecut", d.numar, d.instanta,
                        t.complet, s[0], s[1], d.obiect}});
            }
        }
        Collections.sort(viit, (a, b) -> ((String) a[0]).compareTo((String) b[0]));
        Collections.sort(trec, (a, b) -> ((String) b[0]).compareTo((String) a[0]));
        for (Object[] o : viit) {
            ft.randuri.add((String[]) o[1]);
            ft.evidentiat.add(true);
        }
        for (Object[] o : trec) {
            ft.randuri.add((String[]) o[1]);
            ft.evidentiat.add(false);
        }

        Foaie[] foi = {fd, ft};
        Siruri sir = new Siruri();
        Map<String, String> parti = new LinkedHashMap<>();
        StringBuilder sheets = new StringBuilder(), rels = new StringBuilder(), names = new StringBuilder(),
                overrides = new StringBuilder(), titluriFoi = new StringBuilder();
        Map<String, String> foiXml = new LinkedHashMap<>();
        for (int i = 0; i < foi.length; i++) {
            Foaie f = foi[i];
            int n = i + 1;
            foiXml.put("xl/worksheets/sheet" + n + ".xml", foaieXml(sir, f));
            sheets.append("<sheet name=\"").append(Xml.esc(f.nume)).append("\" sheetId=\"").append(n)
                    .append("\" r:id=\"rId").append(n).append("\"/>");
            rels.append("<Relationship Id=\"rId").append(n)
                    .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                    .append(n).append(".xml\"/>");
            names.append("<definedName name=\"_xlnm._FilterDatabase\" localSheetId=\"").append(i)
                    .append("\" hidden=\"1\">'").append(Xml.esc(f.nume)).append("'!$A$1:$")
                    .append(col(f.titluri.length - 1)).append("$").append(f.randuri.size() + 1).append("</definedName>");
            overrides.append("<Override PartName=\"/xl/worksheets/sheet").append(n)
                    .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            titluriFoi.append("<vt:lpstr>").append(Xml.esc(f.nume)).append("</vt:lpstr>");
        }
        int n = foi.length;
        rels.append("<Relationship Id=\"rId").append(n + 1)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
        rels.append("<Relationship Id=\"rId").append(n + 2)
                .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\" Target=\"sharedStrings.xml\"/>");

        String acum = azi + "T00:00:00Z";
        parti.put("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + overrides
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                + "<Override PartName=\"/xl/sharedStrings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml\"/>"
                + "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
                + "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>"
                + "</Types>");
        parti.put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
                + "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>"
                + "</Relationships>");
        parti.put("docProps/core.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" "
                + "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" "
                + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                + "<dc:title>Dosare instanta</dc:title><dc:creator>Cauta Dosare</dc:creator>"
                + "<dcterms:created xsi:type=\"dcterms:W3CDTF\">" + acum + "</dcterms:created>"
                + "<dcterms:modified xsi:type=\"dcterms:W3CDTF\">" + acum + "</dcterms:modified>"
                + "</cp:coreProperties>");
        parti.put("docProps/app.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" "
                + "xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">"
                + "<Application>Microsoft Excel</Application>"
                + "<HeadingPairs><vt:vector size=\"2\" baseType=\"variant\"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant>"
                + "<vt:variant><vt:i4>" + n + "</vt:i4></vt:variant></vt:vector></HeadingPairs>"
                + "<TitlesOfParts><vt:vector size=\"" + n + "\" baseType=\"lpstr\">" + titluriFoi + "</vt:vector></TitlesOfParts>"
                + "</Properties>");
        parti.put("xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                + "<workbookPr/><bookViews><workbookView activeTab=\"0\"/></bookViews>"
                + "<sheets>" + sheets + "</sheets><definedNames>" + names + "</definedNames></workbook>");
        parti.put("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + rels + "</Relationships>");
        parti.putAll(foiXml);
        parti.put("xl/styles.xml", STILURI);
        parti.put("xl/sharedStrings.xml", sir.xml());
        return zip(parti);
    }

    private static final String STILURI = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
            + "<fonts count=\"3\">"
            + "<font><sz val=\"14\"/><color rgb=\"FF000000\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
            + "<font><b/><sz val=\"14\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
            + "<font><b/><sz val=\"14\"/><color rgb=\"FF000000\"/><name val=\"Calibri\"/><family val=\"2\"/></font>"
            + "</fonts>"
            + "<fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill>"
            + "<fill><patternFill patternType=\"gray125\"/></fill>"
            + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF1F4E79\"/><bgColor indexed=\"64\"/></patternFill></fill>"
            + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFF2CC\"/><bgColor indexed=\"64\"/></patternFill></fill>"
            + "</fills>"
            + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
            + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
            + "<cellXfs count=\"4\">"
            + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
            + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf>"
            + "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf>"
            + "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf>"
            + "</cellXfs>"
            + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
            + "<dxfs count=\"0\"/><tableStyles count=\"0\" defaultTableStyle=\"TableStyleMedium2\" defaultPivotStyle=\"PivotStyleLight16\"/>"
            + "</styleSheet>";

    private static byte[] zip(Map<String, String> parti) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(out)) {
            for (Map.Entry<String, String> e : parti.entrySet()) {
                z.putNextEntry(new ZipEntry(e.getKey()));
                z.write(e.getValue().getBytes(StandardCharsets.UTF_8));
                z.closeEntry();
            }
        }
        return out.toByteArray();
    }
}
