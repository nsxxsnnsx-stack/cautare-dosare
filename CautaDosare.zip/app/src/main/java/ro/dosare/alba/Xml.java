package ro.dosare.alba;

/** Mici utilitare pentru scrierea de XML. */
final class Xml {
    private Xml() {
    }

    /** Escapare XML + eliminarea caracterelor de control interzise in XML. */
    static String esc(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': b.append("&amp;"); break;
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                case '\'': b.append("&apos;"); break;
                default:
                    if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') break;
                    b.append(c);
            }
        }
        return b.toString();
    }
}
