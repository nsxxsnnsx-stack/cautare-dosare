package ro.dosare.alba;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import ro.dosare.alba.Portal.Dosar;
import ro.dosare.alba.Portal.Termen;

public class MainActivity extends Activity {

    private static final int ALBASTRU = Color.rgb(0x1F, 0x4E, 0x79);
    private static final int GALBEN = Color.rgb(0xFF, 0xF2, 0xCC);
    private static final int MARO = Color.rgb(0x9C, 0x57, 0x00);
    private static final int GRI = Color.rgb(0x59, 0x59, 0x59);
    private static final int ROSU = Color.rgb(0xC0, 0x00, 0x00);

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private EditText etNume, etData;
    private Button btnCauta;
    private TextView tvStare, tvRezultate;
    private LinearLayout randSalvare;
    private ScrollView scroll;
    private SharedPreferences pref;
    private float marimeText;

    private List<Dosar> ultimeleDosare;
    private String ultimulNume, ziuaCautarii;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pref = getSharedPreferences("setari", Context.MODE_PRIVATE);
        marimeText = pref.getFloat("marime", 18f);
        construiesteEcran();
        etNume.setText(pref.getString("nume", ""));
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ ecran

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private LinearLayout.LayoutParams latimeIntreaga(int margineSus) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(margineSus);
        return lp;
    }

    private Button buton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        b.setOnClickListener(l);
        return b;
    }

    private void construiesteEcran() {
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(32));
        scroll.addView(col);

        TextView titlu = new TextView(this);
        titlu.setText("Căutare dosare\nInstanțele din Alba Iulia");
        titlu.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        titlu.setTypeface(Typeface.DEFAULT_BOLD);
        titlu.setTextColor(ALBASTRU);
        col.addView(titlu, latimeIntreaga(0));

        TextView info = new TextView(this);
        info.setText("Judecătoria Alba Iulia, Tribunalul Alba și Curtea de Apel Alba Iulia");
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        info.setTextColor(GRI);
        col.addView(info, latimeIntreaga(4));

        etNume = new EditText(this);
        etNume.setHint("Nume firmă sau persoană");
        etNume.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        etNume.setSingleLine(true);
        etNume.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        etNume.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        etNume.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                pornesteCautarea();
                return true;
            }
            return false;
        });
        col.addView(etNume, latimeIntreaga(16));

        etData = new EditText(this);
        etData.setHint("De la data (opțional), ex. 2020-01-01");
        etData.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        etData.setSingleLine(true);
        etData.setInputType(InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_DATE);
        col.addView(etData, latimeIntreaga(8));

        btnCauta = buton("CAUTĂ", v -> pornesteCautarea());
        btnCauta.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        btnCauta.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(btnCauta, latimeIntreaga(12));

        LinearLayout randText = new LinearLayout(this);
        randText.setOrientation(LinearLayout.HORIZONTAL);
        randText.setGravity(Gravity.CENTER_VERTICAL);
        TextView etMarime = new TextView(this);
        etMarime.setText("Mărime text:");
        etMarime.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        randText.addView(etMarime);
        randText.addView(buton("A−", v -> schimbaMarimea(-2)));
        randText.addView(buton("A+", v -> schimbaMarimea(+2)));
        col.addView(randText, latimeIntreaga(8));

        tvStare = new TextView(this);
        tvStare.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvStare.setTextColor(GRI);
        col.addView(tvStare, latimeIntreaga(8));

        randSalvare = new LinearLayout(this);
        randSalvare.setOrientation(LinearLayout.VERTICAL);
        randSalvare.setVisibility(View.GONE);
        randSalvare.addView(buton("Salvează în Word", v -> salveaza(true)), latimeIntreaga(0));
        randSalvare.addView(buton("Salvează în Excel", v -> salveaza(false)), latimeIntreaga(4));
        randSalvare.addView(buton("Deschide ReJust (text complet hotărâri)",
                v -> deschide(Uri.parse("https://www.rejust.ro"), null)), latimeIntreaga(4));
        col.addView(randSalvare, latimeIntreaga(12));

        tvRezultate = new TextView(this);
        tvRezultate.setTextSize(TypedValue.COMPLEX_UNIT_SP, marimeText);
        tvRezultate.setTextColor(Color.BLACK);
        tvRezultate.setTextIsSelectable(true);
        tvRezultate.setLineSpacing(0, 1.15f);
        col.addView(tvRezultate, latimeIntreaga(12));

        scroll.setBackgroundColor(Color.WHITE);
        setContentView(scroll);
    }

    private void schimbaMarimea(int delta) {
        marimeText = Math.max(12f, Math.min(34f, marimeText + delta));
        tvRezultate.setTextSize(TypedValue.COMPLEX_UNIT_SP, marimeText);
        pref.edit().putFloat("marime", marimeText).apply();
    }

    // ------------------------------------------------------------------ cautare

    private void pornesteCautarea() {
        final String nume = etNume.getText().toString().trim();
        final String data = etData.getText().toString().trim();
        if (nume.isEmpty()) {
            etNume.setError("Scrie un nume");
            return;
        }
        if (!data.isEmpty()) {
            try {
                LocalDate.parse(data);
            } catch (DateTimeParseException e) {
                etData.setError("Data trebuie scrisă AAAA-LL-ZZ, ex. 2020-01-01");
                return;
            }
        }
        ascundeTastatura();
        pref.edit().putString("nume", nume).apply();
        btnCauta.setEnabled(false);
        randSalvare.setVisibility(View.GONE);
        tvRezultate.setText("");
        tvStare.setText("Se caută…");
        final String azi = LocalDate.now().toString();

        executor.execute(() -> {
            Portal.Rezultat rez = Portal.cauta(nume, data.isEmpty() ? null : data, azi,
                    mesaj -> ui.post(() -> tvStare.setText(mesaj)));
            boolean internet = rez.instanteReusite > 0 || Portal.areInternet();
            ui.post(() -> afiseaza(nume, azi, rez, internet));
        });
    }

    private void ascundeTastatura() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && getCurrentFocus() != null) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    // ------------------------------------------------------------------ afisare

    private static void adauga(SpannableStringBuilder sb, String text, Object... stiluri) {
        int start = sb.length();
        sb.append(text);
        for (Object s : stiluri) sb.setSpan(s, start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private static void titlu(SpannableStringBuilder sb, String text) {
        adauga(sb, text + "\n", new StyleSpan(Typeface.BOLD), new RelativeSizeSpan(1.25f),
                new ForegroundColorSpan(ALBASTRU));
    }

    private void afiseaza(String nume, String azi, Portal.Rezultat rez, boolean internet) {
        btnCauta.setEnabled(true);
        SpannableStringBuilder sb = new SpannableStringBuilder();

        if (rez.instanteReusite == 0) {
            tvStare.setText("");
            if (internet) {
                adauga(sb, "Internetul merge, dar portalul instanțelor nu a răspuns.\n\n",
                        new StyleSpan(Typeface.BOLD), new ForegroundColorSpan(ROSU));
            } else {
                adauga(sb, "Telefonul nu are acces la internet. Verifică WiFi / datele mobile "
                        + "și că modul Avion e oprit.\n\n", new StyleSpan(Typeface.BOLD), new ForegroundColorSpan(ROSU));
            }
            for (String e : rez.erori) adauga(sb, "• " + e + "\n", new ForegroundColorSpan(GRI));
            tvRezultate.setText(sb);
            return;
        }

        tvStare.setText(rez.dosare.size() + " dosare găsite");
        if (!rez.erori.isEmpty()) {
            adauga(sb, "Atenție: unele instanțe nu au răspuns, rezultatul e incomplet.\n",
                    new StyleSpan(Typeface.BOLD), new ForegroundColorSpan(ROSU));
            for (String e : rez.erori) adauga(sb, "• " + e + "\n", new ForegroundColorSpan(GRI));
            sb.append("\n");
        }
        if (rez.dosare.isEmpty()) {
            adauga(sb, "Nu am găsit dosare pentru „" + nume + "” la instanțele din Alba Iulia.\n",
                    new StyleSpan(Typeface.BOLD));
            tvRezultate.setText(sb);
            return;
        }

        // termene viitoare, din toate dosarele
        titlu(sb, "TERMENE VIITOARE");
        List<Object[]> viitoare = Rapoarte.termeneViitoare(rez.dosare);
        if (viitoare.isEmpty()) {
            sb.append("Nu există termene viitoare.\n");
        } else {
            for (Object[] o : viitoare) {
                Termen t = (Termen) o[0];
                Dosar d = (Dosar) o[1];
                adauga(sb, Rapoarte.cand(t) + "\n", new StyleSpan(Typeface.BOLD), new BackgroundColorSpan(GALBEN));
                sb.append("Dosar ").append(d.numar).append(" – ").append(d.instanta).append("\n");
                adauga(sb, d.obiect + "\n\n", new ForegroundColorSpan(GRI));
            }
        }
        sb.append("\n");

        // fiecare dosar
        titlu(sb, "DOSARE");
        for (Dosar d : rez.dosare) {
            sb.append("\n");
            adauga(sb, "Dosar " + d.numar + "\n", new StyleSpan(Typeface.BOLD), new ForegroundColorSpan(ALBASTRU),
                    new RelativeSizeSpan(1.1f));
            adauga(sb, d.instanta + "\n", new StyleSpan(Typeface.BOLD));
            sb.append("Înregistrat: ").append(Rapoarte.dataRo(d.dataInregistrare)).append("\n");
            sb.append(d.materie).append(" | ").append(d.stadiu).append("\n");
            sb.append("Obiect: ").append(d.obiect).append("\n");
            sb.append("Părți: ").append(d.parti).append("\n");
            if (!d.viitoare.isEmpty()) {
                adauga(sb, "Termene viitoare:\n", new StyleSpan(Typeface.BOLD), new ForegroundColorSpan(MARO));
                for (Termen t : d.viitoare) {
                    adauga(sb, "  » " + Rapoarte.cand(t) + "\n", new StyleSpan(Typeface.BOLD),
                            new BackgroundColorSpan(GALBEN));
                }
            }
            if (!d.trecute.isEmpty()) {
                adauga(sb, "Termene trecute:\n", new StyleSpan(Typeface.BOLD));
                for (int i = d.trecute.size() - 1; i >= 0; i--) {
                    Termen t = d.trecute.get(i);
                    String[] s = Rapoarte.solutie(t);
                    sb.append("  • ").append(Rapoarte.cand(t)).append("\n");
                    sb.append("     ").append(s[0]).append("\n");
                    if (!s[1].isEmpty()) adauga(sb, "     " + s[1] + "\n", new ForegroundColorSpan(GRI));
                }
            }
            if (d.viitoare.isEmpty() && d.trecute.isEmpty()) sb.append("Nu sunt termene afișate pe portal.\n");
        }

        List<String> hot = Rapoarte.hotarariDeCautat(rez.dosare);
        if (!hot.isEmpty()) {
            sb.append("\n");
            titlu(sb, "TEXT COMPLET HOTĂRÂRI");
            adauga(sb, "Se găsește pe www.rejust.ro (cont gratuit), căutând după numărul dosarului:\n",
                    new ForegroundColorSpan(GRI));
            for (String h : hot) sb.append("• ").append(h).append("\n");
        }

        tvRezultate.setText(sb);
        ultimeleDosare = rez.dosare;
        ultimulNume = nume;
        ziuaCautarii = azi;
        randSalvare.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ salvare

    private void salveaza(boolean word) {
        if (ultimeleDosare == null) return;
        final String ext = word ? ".docx" : ".xlsx";
        final String mime = word
                ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        final String numeFisier = Rapoarte.numeFisier(ultimulNume, ziuaCautarii)
                + "_" + System.currentTimeMillis() % 100000 + ext;
        final List<Dosar> dosare = ultimeleDosare;
        final String nume = ultimulNume, azi = ziuaCautarii;
        tvStare.setText("Se salvează…");

        executor.execute(() -> {
            try {
                byte[] date = word ? Rapoarte.word(nume, dosare, azi) : Rapoarte.excel(dosare, azi);
                ContentResolver cr = getContentResolver();
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, numeFisier);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("nu am putut crea fișierul în Download");
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) throw new Exception("nu am putut scrie fișierul");
                    os.write(date);
                }
                ui.post(() -> {
                    tvStare.setText("Salvat în Download: " + numeFisier);
                    Toast.makeText(this, "Salvat în Download", Toast.LENGTH_SHORT).show();
                    deschide(uri, mime);
                });
            } catch (Exception e) {
                ui.post(() -> tvStare.setText("Eroare la salvare: " + e.getMessage()));
            }
        });
    }

    private void deschide(Uri uri, String mime) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        if (mime != null) {
            i.setDataAndType(uri, mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else {
            i.setData(uri);
        }
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, mime != null
                    ? "Fișierul e în Download. Instalează Word/Excel sau Google Docs/Sheets ca să-l deschizi."
                    : "Nu am găsit un browser.", Toast.LENGTH_LONG).show();
        }
    }
}
