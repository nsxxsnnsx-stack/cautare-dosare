package ro.dosare.alba;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Cautarea dosarelor prin serviciul public al portal.just.ro (portalquery.just.ro).
 * Nu depinde de Android, ca sa poata fi testata si pe calculator.
 */
public final class Portal {

    /** Instantele cu sediul in Alba Iulia: {cod serviciu, nume afisat}. */
    public static final String[][] INSTANTE = {
            {"JudecatoriaALBAIULIA", "Judecătoria Alba Iulia"},
            {"TribunalulALBA", "Tribunalul Alba"},
            {"CurteadeApelALBAIULIA", "Curtea de Apel Alba Iulia"},
    };

    private static final String[] URLURI = {
            "https://portalquery.just.ro/query.asmx",
            "http://portalquery.just.ro/query.asmx",
    };
    private static volatile String urlBun = null;

    private Portal() {
    }

    // ------------------------------------------------------------------ model

    public static final class Termen {
        public String data = "", ora = "", complet = "", solutie = "", sumar = "";
        public String document = "", nrDoc = "", dataPronuntare = "";

        public boolean areSolutie() {
            return !solutie.isEmpty() || !sumar.isEmpty();
        }

        String cheie() {
            return data + " " + ora;
        }
    }

    public static final class Dosar {
        public String numar = "", dataInregistrare = "", institutie = "", instanta = "";
        public String materie = "", stadiu = "", obiect = "", parti = "";
        public final List<Termen> viitoare = new ArrayList<>();
        public final List<Termen> trecute = new ArrayList<>();
    }

    public static final class Rezultat {
        public final List<Dosar> dosare = new ArrayList<>();
        public final List<String> erori = new ArrayList<>();
        public int instanteReusite = 0;
    }

    public interface Progres {
        void mesaj(String text);
    }

    // ------------------------------------------------------------------ cautare

    /**
     * Cauta la toate instantele din Alba Iulia.
     *
     * @param nume      numele partii
     * @param dataStart AAAA-LL-ZZ sau null
     * @param azi       AAAA-LL-ZZ (data de azi, pentru a separa termenele viitoare)
     */
    public static Rezultat cauta(String nume, String dataStart, String azi, Progres progres) {
        Rezultat rez = new Rezultat();
        for (String[] inst : INSTANTE) {
            if (progres != null) progres.mesaj("Caut la " + inst[1] + "…");
            try {
                byte[] raspuns = cerere(nume, inst[0], dataStart, azi);
                List<Dosar> lista = parseaza(raspuns, azi);
                for (Dosar d : lista) d.instanta = inst[1];
                rez.dosare.addAll(lista);
                rez.instanteReusite++;
            } catch (Exception e) {
                rez.erori.add(inst[1] + ": " + e.getMessage());
            }
        }
        Collections.sort(rez.dosare, (a, b) -> b.dataInregistrare.compareTo(a.dataInregistrare));
        return rez;
    }

    static String corpCerere(String nume, String cod, String dataStart, String azi) {
        String date = "";
        if (dataStart != null && !dataStart.isEmpty()) {
            date = "<dataStart>" + dataStart + "T00:00:00</dataStart>"
                    + "<dataStop>" + azi + "T23:59:59</dataStop>";
        }
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                + "<soap:Body><CautareDosare xmlns=\"portalquery.just.ro\">"
                + "<numeParte>" + Xml.esc(nume) + "</numeParte>"
                + "<institutie>" + cod + "</institutie>"
                + date
                + "</CautareDosare></soap:Body></soap:Envelope>";
    }

    static byte[] cerere(String nume, String cod, String dataStart, String azi) throws IOException {
        byte[] corp = corpCerere(nume, cod, dataStart, azi).getBytes(StandardCharsets.UTF_8);
        String[] urluri = urlBun != null ? new String[]{urlBun} : URLURI;
        IOException ultima = null;
        for (String adresa : urluri) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(adresa).openConnection();
                con.setRequestMethod("POST");
                con.setConnectTimeout(30000);
                con.setReadTimeout(90000);
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
                con.setRequestProperty("SOAPAction", "\"portalquery.just.ro/CautareDosare\"");
                con.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) CautaDosare");
                try (OutputStream os = con.getOutputStream()) {
                    os.write(corp);
                }
                int cod_http = con.getResponseCode();
                if (cod_http >= 200 && cod_http < 300) {
                    byte[] date = citeste(con.getInputStream());
                    urlBun = adresa;
                    return date;
                }
                String eroare = "";
                InputStream es = con.getErrorStream();
                if (es != null) eroare = new String(citeste(es), StandardCharsets.UTF_8);
                ultima = new IOException("portalul a răspuns cu eroarea " + cod_http + ". " + detaliuEroare(eroare));
            } catch (UnknownHostException e) {
                ultima = new IOException("adresa portalului nu poate fi găsită (fără internet?)");
            } catch (SocketTimeoutException e) {
                ultima = new IOException("portalul nu a răspuns în timp util");
            } catch (IOException e) {
                ultima = new IOException("conexiune eșuată: " + e.getMessage());
            } finally {
                if (con != null) con.disconnect();
            }
        }
        throw ultima != null ? ultima : new IOException("eroare necunoscută");
    }

    static String detaliuEroare(String corp) {
        Matcher m = Pattern.compile("<faultstring>(.*?)</faultstring>", Pattern.DOTALL).matcher(corp);
        String t = m.find() ? m.group(1) : corp;
        t = t.trim();
        return t.length() > 200 ? t.substring(0, 200) : t;
    }

    private static byte[] citeste(InputStream in) throws IOException {
        try (InputStream is = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    public static boolean areInternet() {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL("https://www.google.com").openConnection();
            con.setConnectTimeout(10000);
            con.setReadTimeout(10000);
            return con.getResponseCode() > 0;
        } catch (IOException e) {
            return false;
        } finally {
            if (con != null) con.disconnect();
        }
    }

    // ------------------------------------------------------------------ citire raspuns

    public static List<Dosar> parseaza(byte[] xml, String azi) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try {
            f.setExpandEntityReferences(false);
        } catch (Exception ignored) {
        }
        DocumentBuilder b = f.newDocumentBuilder();
        Document doc = b.parse(new java.io.ByteArrayInputStream(xml));
        NodeList noduri = doc.getElementsByTagNameNS("*", "Dosar");
        List<Dosar> rez = new ArrayList<>();
        for (int i = 0; i < noduri.getLength(); i++) {
            Element el = (Element) noduri.item(i);
            Dosar d = new Dosar();
            d.numar = text(el, "numar");
            d.dataInregistrare = scurt(text(el, "data"), 10);
            d.institutie = text(el, "institutie");
            d.materie = primul(text(el, "categorieCazNume"), text(el, "categorieCaz"));
            d.stadiu = primul(text(el, "stadiuProcesualNume"), text(el, "stadiuProcesual"));
            d.obiect = text(el, "obiect");

            StringBuilder parti = new StringBuilder();
            Element ep = copil(el, "parti");
            if (ep != null) {
                for (Element p : copii(ep)) {
                    if (parti.length() > 0) parti.append("; ");
                    parti.append(text(p, "nume")).append(" (").append(text(p, "calitateParte")).append(")");
                }
            }
            d.parti = parti.toString();

            List<Termen> toate = new ArrayList<>();
            Element es = copil(el, "sedinte");
            if (es != null) {
                for (Element s : copii(es)) {
                    Termen t = new Termen();
                    t.data = scurt(text(s, "data"), 10);
                    t.ora = scurt(text(s, "ora"), 5);
                    t.complet = text(s, "complet");
                    t.solutie = text(s, "solutie");
                    t.sumar = text(s, "solutieSumar");
                    t.document = text(s, "documentSedinta");
                    t.nrDoc = text(s, "numarDocument");
                    t.dataPronuntare = scurt(text(s, "dataPronuntare"), 10);
                    toate.add(t);
                }
            }
            Collections.sort(toate, (x, y) -> x.cheie().compareTo(y.cheie()));
            for (Termen t : toate) {
                if (t.data.compareTo(azi) >= 0 && !t.areSolutie()) d.viitoare.add(t);
                else d.trecute.add(t);
            }
            rez.add(d);
        }
        return rez;
    }

    private static List<Element> copii(Element el) {
        List<Element> rez = new ArrayList<>();
        NodeList nl = el.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n.getNodeType() == Node.ELEMENT_NODE) rez.add((Element) n);
        }
        return rez;
    }

    private static Element copil(Element el, String nume) {
        for (Element c : copii(el)) {
            String ln = c.getLocalName() != null ? c.getLocalName() : c.getNodeName();
            if (nume.equals(ln)) return c;
        }
        return null;
    }

    private static String text(Element el, String nume) {
        Element c = copil(el, nume);
        if (c == null) return "";
        String t = c.getTextContent();
        return t == null ? "" : t.trim();
    }

    private static String scurt(String s, int n) {
        return s.length() > n ? s.substring(0, n) : s;
    }

    private static String primul(String a, String b) {
        return a.isEmpty() ? b : a;
    }
}
